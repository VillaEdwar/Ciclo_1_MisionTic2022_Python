def listarNumeros():
  for i in  range (1, 6):
    print ("Número",i)
  print (i)
#listarNumeros()

def muestraAlgo2( ):
  for j in range (0,101): 
    if ((j % 3) == 0):
      print ("El valor de J es", j)
    else:
     print (j,"NO es divisible por 3" )



def cicloPrueba():
  for i  in range (18, 10, -2):
    print (i)



def cicloPrueba():
  for i  in range (18, 10, -3):
    print (i)

#muestraAlgo2( )
cicloPrueba()

      
def  mostrarNumeros():
	
    print ("El número es: 1")
    print ("El número es: 2")
    print ("El número es: 3")
    print ("El número es: 4")
    print ("El número es: 5")
    print ("El número es: 6")
    print ("El número es: 7")
    print ("El número es: 8")
    print ("El número es: 9")
    print ("El número es: 10")
	       

def usoFor1():
    for i in range (1, 10,1):
        print (i)
  
           


def usoFor2():
    n=100
    for i in range (0, n, 2):
     print (i)


def ejemplo1():
    n=100
    for i in  range (0, (n+1), 1):
        print (i)


def ejemplo2():
    n=0
    for i in  range (100, (n-1), -1):
        print (i)

        
def listarNumeros():
    for i in  range (0, 6):
        print ("Número",i)


def cicloPrueba():
    for i in range (18, 10, -2):
        print (i)

def muestraAlgo():#divisibles por 2
    for i  in  range (0, 20):
        if (i%2 == 0):
            print ("El valor de i  es ", i)

def muestraAlgo2( ):#divisibles por 3
    for j in range (0,101): 
       if ((j % 3) == 0):
               print ("El valor de J es", j)
       else:
               print (j,"NO es divisible por 3.." )



def muestraAlgo3():
    a=0 

    for k in range (0,5,2):	
      a+=1

    print ("El valor de a es: " , a) 




def estudiantes():
    cantidadEstudiantes = int(input("Digite la cantidad de estudiantes "))
    listadoEstudiantes = ""
    nombreEstudiante = ""
    for i in range(0,cantidadEstudiantes):
        nombreEstudiante = input("Digite el nombre del estudiante " + str(i+1)+ ": ")
        listadoEstudiantes = listadoEstudiantes + '\n' + nombreEstudiante 

    print ("\nLos nombres de los " + str(cantidadEstudiantes) + " estudiantes son: ")
    print (listadoEstudiantes)      
        


def factorial(n):
    factorial = 1
    for i in range(1,n+1):
        factorial = factorial * i
    respuesta="El factorial de " ,n , "es: " , factorial
    print(respuesta)
    



def listaFactorial(n):
	if(n<=20):
		for i in range(1,n+1):
			factorial = 1
			for j in range(1,i+1):
				factorial *= j
			respuesta="El factorial de", i ,"es:",factorial
			print(respuesta)
	else:
		respuesta="Ha digitado un número superior a 20"
		print(respuesta)






def crearFigura(numeroFilas):
	triangulo = ""
	for i in range(1,numeroFilas+1):
		for j in range(1,i+1):
			triangulo = triangulo + "*"
		triangulo =triangulo + "\n"
	print(triangulo)




def esMultiploDeTres(a):
    if(a%3 == 0):
      return True
    else:
      return False

	
def multiploDeTres(n):
    contador=0

    for i in range(1,n+1):
      if(esMultiploDeTres(i)):
        contador = contador + 1

    print("La cantidad de números multiplos de 3 desde 1 hasta " + str(n) + " es "+ str(contador))

def funcion2(n):
    

    for i in range(1,n+1):
      if((n%i)==0):
        print (i)

funcion2(10)    

def main():
    #mostrarNumeros()
    usoFor1()
    #usoFor2()
    #ejemplo1()
    #ejemplo2()
    #listarNumeros()
    #cicloPrueba()
    #muestraAlgo()
    #muestraAlgo2()
    #muestraAlgo3()
##    estudiantes()
    #factorial(3)
    #listaFactorial(6)
   #crearFigura(6)
    #esMultiploDeTres(9)
    #multiploDeTres(10)
    
    
    
#main()    

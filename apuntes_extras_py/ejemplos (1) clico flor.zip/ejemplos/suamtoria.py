def serie(n):
    suma = 0
    cantidad=0
    for i in range(1,n+1,1):
      suma=suma+i
      if(i%2==0):
        cantidad=cantidad+1       
                 
    print("la suma es igual a ", suma)
    print("la cantidad de números pares es ", cantidad)
      
n=int(input("Ingrese un número"))
serie(n)
    

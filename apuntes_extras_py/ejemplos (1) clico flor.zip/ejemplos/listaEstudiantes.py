#lee una lista de nombres de estudiantes y luego los muestra por pantalla

cantidadEstudiantes = int(input("Ingrese la cantidad de estudiantes: "))
listadoEstudiantes = ""

for i in range(1,cantidadEstudiantes+1):
	nombreEstudiante = input("Ingrese el nombre del estudiante "
                                   +str(i)+ " ")
	listadoEstudiantes = listadoEstudiantes + nombreEstudiante + "\n"

print("Los estudiantes son: \n" + listadoEstudiantes)


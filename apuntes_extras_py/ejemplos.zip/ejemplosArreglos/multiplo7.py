n= int (input ("¿Cuantos numero va a ingresar? "))
numeros=[None]*n

def ingresar():
  for i in range (0,n):
    numeros[i]= int(input ("Ingrese el numero "))
  print("Los números ingresados son " + str(numeros))

def multiplos7():
  for i in range (0,n):
    if (numeros[i]%7==0):
      print(numeros[i])
      print("esta en la posición " ,i)


ingresar()
multiplos7()

#Pide los puntajes de una competencia y calcula el menor
n= int (input ("¿Cuantos competidores son? "))
puntajes=[None]*n

def ingresar():
  for i in range (0,n):
    puntajes[i]= float(input ("Ingrese el puntaje del competidor "))
  print("Los puntajes ingresados son " + str(puntajes))

def menor():
  menor=puntajes[0]
  for i in range (1,n):
    if (puntajes[i]<menor):
      menor=(puntajes[i])
  print("El puntaje menor es " + str(menor))


ingresar()
menor()

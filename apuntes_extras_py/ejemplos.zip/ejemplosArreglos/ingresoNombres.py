
lista= ""
n = int(input("Ingrese el numero de estudiantes: "))
nombre = [None]*n
#Ingreso de los nombres de los estudiantes
for j in range (0,n):
    nombre[j] = (input("Ingrese nombre del estudiante "))  
  
# Despliegue de la lista de estudiantes:
for i in range (0,n):
    lista = lista + str((i+1)) + ". " + nombre[i] + "\n"

print (lista)

titanic = [
    ["Braund, Mr. Owen Harris",0,3,"masculino",22],
    ["Cumings, Mrs. John Bradley (Florence Briggs Thayer)",1,1,"femenino",38],
    ["Heikkinen, Miss. Laina",1,3,"femenino",26],
    ["Futrelle, Mrs. Jacques Heath (Lily May Peel)",1,1,"femenino",35],
    ["Allen, Mr. William Henry",0,3,"masculino",35],
    ["Saundercock, Mr. William Henry",0,3,"masculino",20],
    ["McCarthy, Mr. Timothy J", 0,1,"masculino",54],
    ["Palsson, Master. Gosta Leonard",0,3,"masculino",2],
    ["Johnson, Mrs. Oscar W (Elisabeth Vilhelmina Berg)",1,3,"femenino",27],
    ["Nasser, Mrs. Nicholas (Adele Achem)",1,2,"femenino",14],
    ["Sandstrom, Miss. Marguerite Rut",1,3,"femenino",4]
];


def sumaEdad(matriz):
        suma =0
        n=0
        for k in range (0,len(matriz)):
            for x in range (4,len(matriz[k])):
                suma = suma + matriz[k][x]
                n=n+1
        promedio=suma/n
        print("\n El promedio es: " + str(round(promedio,2)))

sumaEdad(titanic)

def sobrevivientes(matriz):
        
        for k in range (0,len(matriz)):
            for x in range (2,len(matriz[k])):
                if matriz[k][x]==3:
                    a=matriz[k][x]
                    suma=0
                    for k in range (0,len(matriz)):
                        for x in range (len(matriz[k])):

                            print(matriz[k][1])
                            suma = suma + matriz[k][1]
                    print("La cantidad de sobrevivientes que viajaban en la clase " + str(a) + " es de : " + str(suma))
                if matriz[k][x]==2:
                    a=matriz[k][x]
                    suma=0
                    for k in range (0,len(matriz)):
                        for x in range (len(matriz[k])):

                            print(matriz[k][1])
                            suma = suma + matriz[k][1]
                    print("La cantidad de sobrevivientes que viajaban en la clase " + str(a) + " es de : " + str(suma))
                if matriz[k][x]==1:
                    a=matriz[k][x]
                    suma=0
                    for k in range (0,len(matriz)):
                        for x in range (len(matriz[k])):

                            print(matriz[k][1])
                            suma = suma + matriz[k][1]
                    print("La cantidad de sobrevivientes que viajaban en la clase " + str(a) + " es de : " + str(suma))
sobrevivientes(titanic)

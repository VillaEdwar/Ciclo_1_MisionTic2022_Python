def masDamnificados():
    damnificados=["Bolivar", "Magdalena", "Atlántico", "Guajira", "Chocó"]
    arreglo=[]
    

    for i in range(0,len(damnificados)):
        
        cantidad = int (input ("Digite el número de personas damnificadas en el departamento de "+damnificados[i]+": "))
        arreglo.append(cantidad)

    mayor=arreglo[0]

    for i in range(len(arreglo)):
        if (arreglo[i]>mayor):
            mayor=arreglo[i]
            a=damnificados[i]
            
    print("De acuerdo con la información recolectada, el departamento con más personas damnificadas fue: " + a + " con " + str(mayor))

masDamnificados()
